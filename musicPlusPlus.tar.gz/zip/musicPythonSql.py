import mysql.connector
from werkzeug.security import generate_password_hash, check_password_hash

class MusicPlusPlusSQL(object):
    mydb = -1
    def __init__(self):
        global mydb
        mydb = mysql.connector.connect(
            host='localhost',
            user='bdivney',
            passwd='bdivney',
            database='bdivney'
        )

    def emailInUse(self, email):
        dbcursor = mydb.cursor()
        query = 'select count(*) from userData where email=%s'
        args = (email,)
        dbcursor.execute(query, args)
        rows = dbcursor.fetchone()
        print(rows[0] > 0)
        return rows[0] > 0

    def validateUserNameAndPassword(self, username, password):
        dbcursor = mydb.cursor()
        checkUserQuery = 'select pass from userData where user=%s'
        checkUserArgs = (username,)
        dbcursor.execute(checkUserQuery, checkUserArgs)
        rows = dbcursor.fetchall()
        if len(rows) == 1:
            if (check_password_hash(rows[0][0], password)):
                return True
            else:
                return False
        else:
            return False

    def updateUser(self, first, last, email, password, session):
        dbcursor = mydb.cursor()
        query = 'update userData set firstName=%s, lastName = %s, email = %s, pass = %s where user = %s'
        args = (first, last, email, generate_password_hash(password), session['username'])
        dbcursor.execute(query, args)
        mydb.commit()
        return True
        
    def updatePreferences(self, username, popularity, acoustics, danceability, energy, instrumentalness, liveness, loudness, speechiness, tempo):
        dbcursor = mydb.cursor()
        checkQuery = 'select count(*) from userPreferences where username=%s'
        insertQuery = 'insert into userPreferences (username, popularity, acoustics, danceability, energy, instrumentalness, liveness, loudness, speechiness, tempo) values (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)'
        updateQuery = 'update userPreferences set popularity = %s, acoustics = %s, danceability = %s, energy=%s, instrumentalness=%s, liveness=%s, loudness=%s, speechiness = %s, tempo = %s where username = %s'
        checkArgs = (username, )
        insertArgs = (username, popularity, acoustics, danceability, energy, instrumentalness, liveness, loudness, speechiness, tempo)
        updateArgs = (popularity, acoustics, danceability, energy, instrumentalness, liveness, loudness, speechiness, tempo, username)
        dbcursor.execute(checkQuery, checkArgs)
        if dbcursor.fetchall()[0][0] != 0:
            dbcursor.execute(updateQuery, updateArgs)
            mydb.commit()
            print('updated')
        else:
            dbcursor.execute(insertQuery, insertArgs)
            mydb.commit()
            print('committed')
        return True
    def deleteUser(self, username):
        mycursor  = mydb.cursor()
        deleteUserQuery = 'delete from userData where user=%s'
        deleteUserArgs = (username,)
        mycursor.execute(deleteUserQuery, deleteUserArgs)
        mydb.commit()
        return True

    def createUser(self, username, password, firstName, lastName, emailAddress):
        # Check if username or email already exists
        mycursor = mydb.cursor()
        checkUserNameQuery = 'select * from userData where user=%s or email=%s'
        checkUserNameArgs = (username, emailAddress)
        print(checkUserNameArgs)
        mycursor.execute(checkUserNameQuery, checkUserNameArgs)
        if len(mycursor.fetchall()):
            return False

        # Otherwise add the user data into the database
        createUserQuery = 'insert into userData (firstName, lastName, user, pass, email) values (%s, %s, %s, %s, %s)'
        createUserArgs = (firstName, lastName, username, generate_password_hash(password), emailAddress)
        mycursor.execute(createUserQuery, createUserArgs)
        mydb.commit()
        return True

    def songQuery(self, songSearch):
        mycursor = mydb.cursor()
        songQuery = 'select * from songData where trackName like %s or artistName like %s limit 50'
        songSearch = '%' + songSearch + '%'
        songArgs = (songSearch,songSearch)
        mycursor.execute(songQuery, songArgs)
        return mycursor.fetchall()

    def preferenceUserQuery(self, user):
        mycursor = mydb.cursor();
        query = 'select popularity, acoustics, danceability, energy, instrumentalness, liveness, loudness, speechiness, tempo from userPreferences where username=%s orderby popularity'
        args = (user,)
        mycursor.execute(query, args)
        return mycursor.fetchall()

    def genrePreferenceQuery(self):
        mycursor = mydb.cursor();
        query = 'select genre, popularity, acoustics, danceability, energy, instrumentalness, liveness, loudness, speechiness, tempo from genreData'
        mycursor.execute(query)
        return mycursor.fetchall()

    def playlistQuery(self, genre, duration):
        mycursor = mydb.cursor()
        if(duration != -1):
            playlistQuery = 'select trackName, artistName, genre, durationMS, trackId, tempo from songData where genre=%s and durationMS*1.05 >= %s and durationMS*0.95 <= %s'
            playlistArgs = (genre, duration, duration)
            mycursor.execute(playlistQuery, playlistArgs)
        else:
            playlistQuery = 'select trackName, artistName, genre, durationMS, trackId, tempo from songData where genre=%s'
            playlistArgs = (genre, )
            mycursor.execute(playlistQuery, playlistArgs)
        return mycursor.fetchall()

    def createPlaylist(self, playlistSongs):
        mycursor = mydb.cursor()

        # Find the new playlist number for the table
        findMaxQuery = 'select max(playlistId) from playlistData'
        mycursor.execute(findMaxQuery)
        results = mycursor.fetchall()
        if not results[0][0]:
            playlistNum = 1
        else:
            playlistNum = results[0][0] + 1

        # Add the songs into the playlist table
        playlistAddQuery = 'insert into playlistData(playlistId, trackID) values (%s, %s)'
        for song in playlistSongs:
            playlistAddArgs = (playlistNum, song[4])
            mycursor.execute(playlistAddQuery, playlistAddArgs)
            mydb.commit()
        return playlistNum

    def addPlaylistToUser(self, playlistNumber, user, name):
        mycursor = mydb.cursor()
        addPlaylistQuery = 'insert into userPlaylists(username, playlistId, name) values (%s, %s, %s)'
        addPlaylistArgs = (user, playlistNumber, name)
        mycursor.execute(addPlaylistQuery, addPlaylistArgs)
        mydb.commit()
        return True

    def getUserPlaylists(self, username):
        mycursor = mydb.cursor()
        getPlaylistsQuery = 'select * from userPlaylists where username = %s'
        mycursor.execute(getPlaylistsQuery, (username, ))
        return mycursor.fetchall()

    def getPlaylistName(self, playlistID):
        mycursor = mydb.cursor()
        getName = 'select name from userPlaylists where playlistID = %s'
        mycursor.execute(getName, (playlistID, ))
        return mycursor.fetchall()[0][0]

    def getUserSinglePlaylist(self, playlistID):
        mycursor = mydb.cursor()
        getPlaylistsQuery = 'select songData.trackID, genre, artistName, trackName, durationMS, tempo from playlistData, songData where playlistId = %s and playlistData.trackID = songData.trackID'
        mycursor.execute(getPlaylistsQuery, (playlistID, ))
        return mycursor.fetchall()

    def removePlaylist(self, playlistID):
        mycursor = mydb.cursor()
        removePlaylistQuery = 'delete from userPlaylists where playlistId = %s'
        mycursor.execute(removePlaylistQuery, (playlistID, ))
        mydb.commit()
        deletePlaylistQuery = 'delete from playlistData where playlistId = %s'
        mycursor.execute(deletePlaylistQuery, (playlistID, ))
        mydb.commit()
        return True

    def checkUserOwnsPlaylist(self, username, playlistID):
        mycursor = mydb.cursor()
        checkPlayListOwnerQuery = "select * from userPlaylists where username = %s and playlistId = %s"
        mycursor.execute(checkPlayListOwnerQuery, (username, playlistID))
        playlistInfo = mycursor.fetchall()
        if len(playlistInfo) != 1:
            return None
        else:
            return playlistInfo[0][2]

    def addSongToPlaylist(self, trackID, playlistID):
        mycursor = mydb.cursor()
        addSongQuery = "insert into playlistData(playlistId, trackID) values(%s, %s)"
        mycursor.execute(addSongQuery, (playlistID, trackID))
        mydb.commit()
        return True

    def findSongInfo(self, trackID):
        mycursor = mydb.cursor()
        findSongQuery = "select * from songData where trackID=%s"
        mycursor.execute(findSongQuery, (trackID, ))
        return mycursor.fetchall()[0]

    def checkUserTookSurvey(self, user):
        mycursor = mydb.cursor()
        surveyQuery = "select * from userPreferences where username = %s"
        mycursor.execute(surveyQuery, (user, ))
        data = mycursor.fetchall()
        if len(data):
            return True
        else:
            return False

    # Cool query - gets the songs with the best of that trait using table join
    def findTracksWithBestTrait(self, trait):
        mycursor = mydb.cursor()
        if trait == "acoustics":
            fullQuery = "select trackID from songData, genreData where songData.genre = genreData.genre and genreData.acoustics = (select max(acoustics) from genreData)";
        elif trait == "liveness":
            fullQuery = "select trackID from songData, genreData where songData.genre = genreData.genre and genreData.liveness = (select max(liveness) from genreData)"
        elif trait == "instrumentalness":
            fullQuery = "select trackID from songData, genreData where songData.genre = genreData.genre and genreData.instrumentalness = (select max(instrumentalness) from genreData)"
        mycursor.execute(fullQuery)
        return mycursor.fetchall()

    # Save the Spotify data and updated refresh_token as needed on querying
    def addSpotifyAuth(self, user, refresh_token, spotifyUser):
        mycursor = mydb.cursor()
        findUserQuery = "select * from spotifyData where user = %s"
        mycursor.execute(findUserQuery, (user, ))
        results = mycursor.fetchall()
        if results:
            mycursor = mydb.cursor()
            addSpotifyAuthQuery1 = 'update spotifyData set authCode = %s where user = %s'
            mycursor.execute(addSpotifyAuthQuery1, (refresh_token, user))
            mydb.commit()
        else:
            mycursor = mydb.cursor()
            addSpotifyAuthQuery = 'insert into spotifyData(user, authCode, spotifyUser) values (%s, %s, %s)'
            mycursor.execute(addSpotifyAuthQuery, (user, refresh_token, spotifyUser))
            mydb.commit()
            return True

    def getRefreshToken(self, username):
        mycursor = mydb.cursor()
        authCodeQuery = 'select authCode from spotifyData where user = %s'
        mycursor.execute(authCodeQuery, (username, ))
        return mycursor.fetchall()[0][0]
