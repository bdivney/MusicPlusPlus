from flask import Flask,session, render_template, request, redirect
from musicPythonSql import MusicPlusPlusSQL
from statistics import stdev
import os
import leather
import musicRequests
import random
app = Flask(__name__)
app.secret_key = "fsdfregrrtejuifwdheqiyfugweydqugfvwyeqdugfh"
musicDB = 1

def define_table():
    global musicDB
    musicDB = MusicPlusPlusSQL()

@app.route('/')
def main():
    if 'username' in session:
        return redirect('/home/')
    return render_template('index.html')

@app.route('/editProfile/', methods=['GET'])
def editProfile():
    if 'username' not in session:
        session['last'] = '/editProfile/'
        return redirect('/login/')
    return render_template('editProfile.html')

@app.route('/editProfile/', methods=['POST'])
def postNewUserData():
    if "Delete" in request.form.keys():
        musicDB.deleteUser(session['username'])
        session.pop('username', None)
        return redirect('/login/')
    elif "Cancel" in request.form.keys():
        return redirect('/')

    try:
        firstName = request.form['firstName']
        lastName = request.form['lastName']
        password = request.form['password']
        passwordConf = request.form['passwordConf']
        email = request.form['email']
        if password != passwordConf:
            return render_template('editProfile.html', error="Passwords do not match.")
        if email != session['username'] and musicDB.emailInUse(email):
            return render_template('editProfile.html', error="Email in use. Please use another.")
    except Exception as e:
        return render_template('editProfile.html', error="An unexpected error occurred. Please try again.")

    if "Update" in request.form.keys():
        musicDB.updateUser(firstName, lastName, email, password, session)
        return redirect('/home/')
    

@app.route('/register/', methods=['GET'])
def signup_page():
    return render_template('register.html')

@app.route('/register/', methods=['POST'])
def signup_post():
    try:
        _inputUserName = request.form["inputUserName"]
        _inputEmail = request.form["inputEmail"]
        _inputFirstName = request.form["inputFirstName"]
        _inputLastName = request.form["inputLastName"]
        _inputPassword = request.form["inputPassword"]
        _verifyPassword = request.form["verifyPassword"]
        if musicDB.emailInUse(_inputEmail):
            return render_template('register.html', error="Email already in use. Please use another.")
        if _inputPassword != _verifyPassword:
            return render_template('register.html', error="Passwords do not match!")

        if musicDB and musicDB.createUser(_inputUserName, _inputPassword, _inputFirstName, _inputLastName, _inputEmail):
            return redirect('/login/')
        else:
            return render_template('register.html', error="Username already in use. Please try another.")
    except Exception as e:
        print(e)
        return render_template('register.html', error="Could not register account! Please try again.")

@app.route('/login/', methods=['GET'])
def login_page():
    return render_template('login.html')

@app.route('/home/')
def home_page():
    if 'username' not in session:
        session['last'] = '/home/'
        return redirect('/login/')

    playlists = musicDB.getUserPlaylists(session['username']) 
    if not len(playlists):
        playlists = [('', '', 'No Playlists Yet!')]

    return render_template('userHome.html', data=playlists)


@app.route('/signOut/', methods=['GET'])
def signOut():
    session.pop("username", None)
    return render_template('login.html')

@app.route('/login/validate', methods=['POST'])
def login_evaluate_post():
	# Get the information from the form
	try:
		_username = request.form['inputUser']
		_password = request.form['inputPassword']
	except Exception as e:
		return render_template('login.html', error="An Unexpected Sign In Error Occurred")

	# Validate the information
	if musicDB and musicDB.validateUserNameAndPassword(_username, _password):
		# Log In And Take to User home
             session["username"] = _username
             if 'last' in session:
                url = session['last']
                session.pop('last', None)
                return redirect(url)
             return redirect('/home/')
	else:
		# Return to Login Page with Error
		return render_template('login.html', error='Invalid username or password. Please try again.')

@app.route('/playlist/', methods=['GET'])
def playlist_get():
    if 'username' not in session:
        session['last'] = '/playlist/'
        return redirect('/login/')
    return render_template('tempoPage.html', user=session["username"])

@app.route('/playlist/', methods=['POST'])
def playlist_post():
    # Get data from the form
    playlistLength = int(request.form['totalLength']) * 1000 * 60
    averageSongLength = int(request.form['avgSongLengthMin']) * 1000 * 60
    averageSongLength += int(request.form['avgSongLengthSec']) * 1000
    genre = request.form['Genre']
    beginTempo = int(request.form['0'])
    beginMiddleTempo = int(request.form['25'])
    middleTempo = int(request.form['50'])
    middleEndTempo = int(request.form['75'])
    endTempo = int(request.form['100'])

    # Find the number of songs and average song length in playlist
    numSongs = round(playlistLength / averageSongLength)
    averageSongLength = playlistLength / numSongs

    graphData = []
    currentTime = 0
    availableSongs = musicDB.playlistQuery(genre, averageSongLength)
    availableSongs = organizeData(availableSongs)
    playlistSongs = []
    errorString = ""

    for songNumber in range(0, numSongs):
        percent = (currentTime + averageSongLength) / playlistLength

        currentTempo = 0
        # Find the tempo at the current length, using distance formula
        if percent >= 0 and percent < .25:
            currentTempo = beginTempo + ((beginMiddleTempo - beginTempo) * percent / .25)
        elif percent >= .25 and percent < .50:
            currentTempo = beginMiddleTempo + ((middleTempo - beginMiddleTempo) * (percent - .25) / .25)
        elif percent >= .50 and percent < .75:
            currentTempo = middleTempo + ((middleEndTempo - middleTempo) * (percent - .5) / .25)
        elif percent >= .75:
            currentTempo = middleEndTempo + ((endTempo - middleEndTempo) * (percent - .75) / .25)

        # Must keep track of songs so as to eliminate duplicates
        foundSong = False
        for i in range(0, len(availableSongs)):
            if availableSongs[i][5] >= currentTempo*.9 and availableSongs[i][5] <= currentTempo*1.1:
                graphData.append((currentTime / 60000, availableSongs[i][5]))
                playlistSongs.append(availableSongs[i])
                currentTime += availableSongs[i][3]
                availableSongs.pop(i)
                foundSong = True
                break
        if not foundSong:
            errorString = "We were unable to generate an appropriate playlist according to your desired specifications. Please try again with different search parameters."
            break

    # Find song that will have the appropriate song length to get exact playlist generated
    if abs(currentTime - playlistLength) > 5000:
        currentTime -= playlistSongs[-1][3]
        playlistSongs.pop(len(playlistSongs) - 1)
        newSongs = musicDB.findRoundedSongs(playlistLength - currentTime, genre, endTempo)
        songLength = False
        for song in newSongs:
            if abs(song[3] - (playlistLength - currentTime)) < 5000:
                playlistSongs.append(song)
                songLength = True
                currentTime += song[3]
                break
        if songLength:
            graphData.pop(len(graphData) - 2)
        else:
            errorString = "Could not create a playlist with the desired runtime. Change your preferences and try again!"

    # Generate the chart to print using leather library
    chart = leather.Chart("")
    chart.set_style("line")
    chart.set_color(255, 0, 0)
    chart.add_y_scale(50, 250)
    chart.add_x_scale(0, currentTime / 6000)
    chart.add_x_axis(ticks =[ 5*x for x in range(round(currentTime / 6000 / 5))] )
    chart.add_y_axis(ticks=[50, 100, 150, 200, 250])
    chart.add_line(graphData)
    playNum = random.randint(1, 1000000)
    chart.to_svg("static/img/graph{}.svg".format(playNum))

    # Set the appropriate fields
    timeMinutes = int(currentTime / 1000 / 60)
    timeSeconds = int(currentTime / 1000 % 60)
    session['playlist'] = playlistSongs

    return render_template('playlistAdd.html', data=playlistSongs, len=len(playlistSongs), user=session['username'], error=errorString, min=timeMinutes, sec=timeSeconds, graph=playNum)

@app.route('/addPlaylist/', methods=['POST'])
def add_playlist():
    playlistName = request.form['playlistName']
    playlistSongs = session['playlist']
    session.pop('playlist', None)

    playlistNumber = musicDB.createPlaylist(playlistSongs)
    musicDB.addPlaylistToUser(playlistNumber, session['username'], playlistName)

    return render_template('playlistAdd.html', data=playlistSongs, len=len(playlistSongs), user=session['username'], error="Successfully added playlist to profile!")


@app.route('/search/', methods=['GET'])
def search_get():
    if 'username' not in session:
        session['last'] = '/search/'
        return redirect('/login/')
    return render_template('search.html', user=session["username"])

@app.route('/search/', methods=['POST'])
def search_post():
    searchTerm = request.form['inputSearch']
    results = musicDB.songQuery(searchTerm)
    if len(results) == 0:
        refresh_token = musicDB.getRefreshToken(session['username'])
        accessToken = musicRequests.update_access_token(refresh_token)
        musicRequests.song_search(accessToken, searchTerm)
    return render_template('search.html',len=len(results), data=results, user=session["username"])

@app.route('/survey/', methods=['GET'])
def survey_get():
    if 'username' not in session:
        session['last'] = '/survey/'
        return redirect('/login/')
    return render_template('survey.html', user=session["username"])

@app.route('/survey/', methods=['POST'])
def survey_post():
    # logic here for inserting survey results into the database
    return redirect('/personality/')

@app.route('/personality/', methods=['GET'])
def personality_edit_get():
    return redirect('/survey/')

@app.route('/personality/', methods=['POST'])
def personality_post():
    # Mapping the personality traits to song traits (intricate)
    traits = {"popularity":50, "acoustics":50, "danceability":50, "energy":50, "instrumentalness":50, "liveness":50, "loudness":50, "speechiness":50, "tempo":50}
    answer = request.form['group1']
    if(answer == 'value1'):
        traits['energy'] = traits['energy'] + 10
        traits['liveness'] = traits['liveness'] + 10
        traits['tempo'] = traits['tempo'] + 10
        traits['loudness'] = traits['loudness'] + 10

    if(answer == 'value2'):
        traits['energy'] = traits['energy'] + 5
        traits['liveness'] = traits['liveness'] + 5
        traits['tempo'] = traits['tempo'] + 5
        traits['loudness'] = traits['loudness'] + 5

    if(answer == 'value4'):
        traits['energy'] = traits['energy'] - 5
        traits['liveness'] = traits['liveness'] - 5
        traits['tempo'] = traits['tempo'] - 5
        traits['loudness'] = traits['loudness'] - 5

    if(answer == 'value5'):
        traits['energy'] = traits['energy'] - 10
        traits['liveness'] = traits['liveness'] - 10
        traits['tempo'] = traits['tempo'] - 10
        traits['loudness'] = traits['loudness'] - 10
    answer = request.form['group2']

    if(answer == 'value1'):
        traits['instrumentalness'] = traits['instrumentalness'] - 10
        traits['tempo'] = traits['tempo'] - 10
        traits['acoustics'] = traits['acoustics'] - 10
        traits['speechiness'] = traits['speechiness'] - 10
        traits['popularity'] = traits['popularity'] - 10
        traits['danceability'] = traits['danceability'] - 10

    if(answer == 'value2'):
        traits['instrumentalness'] = traits['instrumentalness'] - 5
        traits['tempo'] = traits['tempo'] - 5
        traits['acoustics'] = traits['acoustics'] - 5
        traits['speechiness'] = traits['speechiness'] - 5
        traits['popularity'] = traits['popularity'] - 5
        traits['danceability'] = traits['danceability'] - 5

    if(answer == 'value4'):
        traits['instrumentalness'] = traits['instrumentalness'] + 5
        traits['tempo'] = traits['tempo'] + 5
        traits['acoustics'] = traits['acoustics'] + 5
        traits['speechiness'] = traits['speechiness'] + 5
        traits['popularity'] = traits['popularity'] + 5
        traits['danceability'] = traits['danceability'] + 5

    if(answer == 'value5'):
        traits['instrumentalness'] = traits['instrumentalness'] + 10
        traits['tempo'] = traits['tempo'] + 10
        traits['acoustics'] = traits['acoustics'] + 10
        traits['speechiness'] = traits['speechiness'] + 10
        traits['popularity'] = traits['popularity'] + 10
        traits['danceability'] = traits['danceability'] + 10
    answer = request.form['group3']

    if(answer == 'value1'):
        traits['liveness'] = traits['liveness'] + 10
        traits['energy'] = traits['energy'] + 10
        traits['tempo'] = traits['tempo'] + 10
        traits['danceability'] = traits['danceability'] + 10
        traits['popularity'] = traits['popularity'] + 10
        traits['loudness'] = traits['loudness'] + 10

    if(answer == 'value2'):
        traits['liveness'] = traits['liveness'] + 5
        traits['energy'] = traits['energy'] + 5
        traits['tempo'] = traits['tempo'] + 5
        traits['danceability'] = traits['danceability'] + 5
        traits['popularity'] = traits['popularity'] + 5
        traits['loudness'] = traits['loudness'] + 5

    if(answer == 'value4'):
        traits['liveness'] = traits['liveness'] - 5
        traits['energy'] = traits['energy'] - 5
        traits['tempo'] = traits['tempo'] - 5
        traits['danceability'] = traits['danceability'] - 5
        traits['popularity'] = traits['popularity'] - 5
        traits['loudness'] = traits['loudness'] - 5

    if(answer == 'value5'):
        traits['liveness'] = traits['liveness'] - 10
        traits['energy'] = traits['energy'] - 10
        traits['tempo'] = traits['tempo'] - 10
        traits['danceability'] = traits['danceability'] - 10
        traits['popularity'] = traits['popularity'] - 10
        traits['loudness'] = traits['loudness'] - 10
    answer = request.form['group4']
    if(answer == 'value1'):
         traits['acoustics'] = traits['acoustics'] - 10
         traits['danceability'] = traits['danceability'] + 10
         traits['energy'] = traits['energy'] + 10
         traits['liveness'] = traits['liveness'] + 10
         traits['loudness'] = traits['loudness'] + 10
         traits['tempo'] = traits['tempo'] + 10

    if(answer == 'value2'):
         traits['acoustics'] = traits['acoustics'] - 5
         traits['danceability'] = traits['danceability'] + 5
         traits['energy'] = traits['energy'] + 5
         traits['liveness'] = traits['liveness'] + 5
         traits['loudness'] = traits['loudness'] + 5
         traits['tempo'] = traits['tempo'] + 5

    if(answer == 'value4'):
         traits['acoustics'] = traits['acoustics'] + 5
         traits['danceability'] = traits['danceability'] - 5
         traits['energy'] = traits['energy'] - 5
         traits['liveness'] = traits['liveness'] - 5
         traits['loudness'] = traits['loudness'] - 5
         traits['tempo'] = traits['tempo'] - 5

    if(answer == 'value5'):
         traits['acoustics'] = traits['acoustics'] + 10
         traits['danceability'] = traits['danceability'] - 10
         traits['energy'] = traits['energy'] - 10
         traits['liveness'] = traits['liveness'] - 10
         traits['loudness'] = traits['loudness'] - 10
         traits['tempo'] = traits['tempo'] - 10
    answer = request.form['group5']
    if(answer == 'value1'):
         traits['popularity'] = traits['popularity'] - 10
         traits['acoustics'] = traits['acoustics'] + 10
         traits['instrumentalness'] = traits['instrumentalness'] + 10
         traits['liveness'] = traits['liveness'] - 10

    if(answer == 'value2'):
         traits['popularity'] = traits['popularity'] - 5
         traits['acoustics'] = traits['acoustics'] + 5
         traits['instrumentalness'] = traits['instrumentalness'] + 5
         traits['liveness'] = traits['liveness'] - 5

    if(answer == 'value4'):
         traits['popularity'] = traits['popularity'] + 5
         traits['acoustics'] = traits['acoustics'] - 5
         traits['instrumentalness'] = traits['instrumentalness'] - 5
         traits['liveness'] = traits['liveness'] + 5

    if(answer == 'value5'):
         traits['popularity'] = traits['popularity'] + 10
         traits['acoustics'] = traits['acoustics'] - 10
         traits['instrumentalness'] = traits['instrumentalness'] - 10
         traits['liveness'] = traits['liveness'] + 10
    for key,value in traits.items():
       if(value > 100): traits[key] = 100
       if(value < 0): traits[key] = 0
    traits['tempo'] = traits['tempo'] * 2
    return render_template('personality.html', data=traits)

@app.route('/surveyPlaylist/', methods=['GET'])
def surveyPlaylist_get():
    if 'username' not in session:
        session['last'] = '/home/'
        return redirect('/login/')
    if not musicDB.checkUserTookSurvey(session['username']):
        return redirect('/survey/')
    else:
        return render_template('surveyPlaylist.html')
    
def closestGenre(user, multiplier, chosenGenres):
    userPreferences = musicDB.preferenceUserQuery(user)[0]
    genres = musicDB.genrePreferenceQuery()
    smallest = 1000
    smallestGenre = 'hold'
    # The most common genres that are recommended within Music++
    allowedGenres = ['Pop', 'Rap', 'Hip-Hop', 'Electronic', 'Country', 'Rock', 'Dance', 'Alternative']
    for genre in genres:
        if genre[0] not in allowedGenres:
            continue
        if genre[0] in chosenGenres:
            continue
        result = 0.0
        for i in range(1, len(genre)):
            result = result + float(abs(userPreferences[i-1] * multiplier - float(genre[i])))
        if result < smallest:
            smallest = result
            smallestGenre = genre[0]
    return smallestGenre
    
def fisherYates(arr):
    n = len(arr)
    for i in range(n - 1, 0, -1):
        j = random.randint(0, i)
        arr[i],arr[j] = arr[j], arr[i]
    return arr
    
@app.route('/surveyPlaylist/', methods=['POST'])
def surveyPlaylist_post():
    if 'username' not in session:
        session['last'] = '/home/'
        return redirect('/login/')
    time = int(request.form['duration']) / 3 * 60 * 1000;
    randomness = int(request.form['random']) / 100.0;
    chosenGenres = []
    genre1 = closestGenre(session['username'], 1, chosenGenres)
    chosenGenres.append(genre1)
    genre2 = closestGenre(session['username'], 1.0 + float(randomness), chosenGenres)
    chosenGenres.append(genre2)
    genre3 = closestGenre(session['username'], 1.0 - float(randomness), chosenGenres)
    songs1 = musicDB.playlistQuery(genre1, -1)
    songs2 = musicDB.playlistQuery(genre2, -1)
    songs3 = musicDB.playlistQuery(genre3, -1)
    playlist = [];
    timeLeft = time;
    while(timeLeft > 0):
        randSeed = random.randrange(len(songs1))
        playlist.append(songs1[randSeed])
        timeLeft -= songs1[randSeed][3]
    timeLeft = time;
    while(timeLeft > 0):
        randSeed = random.randrange(len(songs2))
        playlist.append(songs2[randSeed])
        timeLeft -= songs2[randSeed][3]
    timeLeft = time;
    while(timeLeft > 0):
        randSeed = random.randrange(len(songs3))
        playlist.append(songs3[randSeed])
        timeLeft -= songs3[randSeed][3]
    playlist = fisherYates(playlist)
    playlistNumber = musicDB.createPlaylist(playlist)
    musicDB.addPlaylistToUser(playlistNumber, session['username'], request.form['name'])
    return redirect('/playlist/{}'.format(playlistNumber))


@app.route('/preferences/', methods=['POST'])
def preferences_post():
    if(len(request.form) < 0): return redirect('/home/')
    popularity = float(request.form['popularity']) / 100.0
    acoustics = float(request.form['acoustics']) / 100.0
    danceability = float(request.form['danceability']) / 100.0
    energy = float(request.form['energy']) / 100.0
    instrumentalness = float(request.form['instrumentalness']) / 100.0
    liveness = float(request.form['liveness']) / 100.0
    loudness = float(request.form['loudness']) / -10.0
    speechiness = float(request.form['speechiness']) / 100
    tempo = request.form['tempo']
    musicDB.updatePreferences(session['username'], popularity, acoustics, danceability, energy, instrumentalness, liveness, loudness, speechiness, tempo)
    
    return redirect('/home/')

@app.route('/playlist/<int:playlistId>', methods=['GET'])
def playlist_individual_get(playlistId):
    if not session['username']:
        return redirect('/')
    playlistName = musicDB.checkUserOwnsPlaylist(session['username'], playlistId)
    if not playlistName:
        return redirect('/home/')
    data = {}
    data['playlist'] = musicDB.getUserSinglePlaylist(playlistId)
    data['playlistName'] = playlistName
    error = None
    if 'error' in session.keys():
        error = session['error']
        session.pop('error')
    return render_template("playlistView.html", data=data, id=playlistId, error=error)

@app.route('/playlist/<int:playlistId>', methods=['POST'])
def playlist_delete(playlistId):
    musicDB.removePlaylist(playlistId)
    return redirect('/home/')

@app.route('/addSong/<string:trackID>', methods=['GET'])
def add_song_to_playlist(trackID):
    song = musicDB.findSongInfo(trackID)
    data = musicDB.getUserPlaylists(session['username'])
    if not len(data):
        playlists = [('', '', 'No Playlists Yet!')]

    return render_template("addSong.html", song=song, data=data)

@app.route('/addSong/<string:trackID>', methods=['POST'])
def add_song_to_new(trackID):
    playlistName = request.form['playlistName']
    playlistNum = musicDB.createPlaylist((('', '', '', '', trackID), ))
    musicDB.addPlaylistToUser(playlistNum, session['username'], playlistName)

    return redirect("/playlist/{}".format(playlistNum))


@app.route('/playlist/<int:playlistID>/<string:trackID>', methods=['GET'])
def add_song_to_existing(playlistID, trackID):
    musicDB.addSongToPlaylist(trackID, playlistID)

    return redirect('/playlist/{}'.format(playlistID))

@app.route('/spotifyAuthorize/', methods=["GET"])
def begin_spotify_authorization():
	return redirect("https://accounts.spotify.com/authorize?client_id=c3e2c8a116844ee6bd514df59c2034bc&response_type=code&redirect_uri=http%3A%2F%2Fdb.cse.nd.edu%3A5004%2FspotifyAuthorize%2Fcomplete%2F&scope=user-read-private%20playlist-modify-private%20playlist-modify-public")

@app.route('/spotifyAuthorize/complete/', methods=["GET"])
def spotify_authorize_complete():
    if 'error' in request.args:
        return redirect('/home/')
    code = request.args.get('code')
    user = session['username']
    
    # have other request here
    tokens = musicRequests.get_access_tokens(code)
    accessToken = tokens[0]
    refreshToken = tokens[1]
    spotifyUser = musicRequests.get_user_id(accessToken)
    session['spotifyUser'] = spotifyUser

    musicDB.addSpotifyAuth(user, refreshToken, spotifyUser)
    return redirect('/home/')

@app.route('/addPlaylistSpotify/<int:playlistID>', methods=['GET'])
def spotify_add_playlist(playlistID):
    refresh_token = musicDB.getRefreshToken(session['username'])
    playlistName = musicDB.getPlaylistName(playlistID)
    accessToken = musicRequests.update_access_token(refresh_token)
    playlistSpotifyID = musicRequests.add_spotify_playlist(accessToken, session['spotifyUser'], playlistName)
    accessToken = musicRequests.update_access_token(refresh_token)
    tracks = musicDB.getUserSinglePlaylist(playlistID)
    snapshot_id = musicRequests.add_track_to_playlist(accessToken, playlistSpotifyID, tracks)
    session['error'] = "Successfully exported playlist \"{}\" to Spotify!".format(playlistName)
    return redirect("/playlist/{}".format(playlistID))

if __name__ == '__main__':
    define_table()
    app.run(host='db.cse.nd.edu', port=5004, debug=True)
