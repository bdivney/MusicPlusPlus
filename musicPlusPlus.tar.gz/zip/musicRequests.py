import requests
import json

base64_string = "Basic YzNlMmM4YTExNjg0NGVlNmJkNTE0ZGY1OWMyMDM0YmM6MDBhNzZmY2FmOWUyNGJiMDhhMjQ3MzE5YzY5MzczODk="

# Original request for access tokens - can be done only once with the authorization code
def get_access_tokens(authcode):
    data = {"grant_type": "authorization_code",
            "code": authcode,
            "redirect_uri": "http://db.cse.nd.edu:5004/spotifyAuthorize/complete/",
            "client_id": "c3e2c8a116844ee6bd514df59c2034bc",
            "client_secret": "00a76fcaf9e24bb08a247319c6937389"}
    r = requests.post("https://accounts.spotify.com/api/token", data=data)
    body = r.json()
    print(body)
    return (body['access_token'], body['refresh_token'])

# After every request, we need to update the access tokens (annoying)
def update_access_token(refresh_token):
    data = {"grant_type": "refresh_token",
            "refresh_token": refresh_token}
    headers = {"Authorization": base64_string}
    r = requests.post("https://accounts.spotify.com/api/token", data=data, headers=headers)
    body = r.json()
    print(body)
    return body['access_token']

# Request to get the user_id from Spotify after sign-in (done with authorization code)
def get_user_id(access_token):
    headers = {"Authorization": "Bearer {}".format(access_token)}
    r = requests.get("https://api.spotify.com/v1/me", headers=headers)
    print(r.json())
    return r.json()['id']

# Create a new playlist for the Spotify user
def add_spotify_playlist(access_token, user_id, name):
    headers = {"Authorization": "Bearer {}".format(access_token),
               "Content-Type": "application/json"}
    data = {"name": name}
    r = requests.post("https://api.spotify.com/v1/users/{}/playlists".format(user_id), headers=headers, data=json.dumps(data))
    print(r.json())
    return r.json()['id']

# Given the playlist, add all the songs (in the correct order!)
# Want to do only one request to minimize need to get new access tokens
def add_track_to_playlist(access_token, playlist_id, trackIDs):
    headers = {"Authorization": "Bearer {}".format(access_token),
               "Content-Type": "application/json"}
    trackList = []
    data = {}
    for track in trackIDs:
        trackList.append("spotify:track:" + track[0])
    if (len(trackList) > 0):
        data['uris'] = trackList
    r = requests.post("https://api.spotify.com/v1/playlists/{}/tracks".format(playlist_id), headers=headers, data=json.dumps(data))
    return r.json()['snapshot_id']

def song_search(access_token, search_string):
    headers = {"Authorization": "Bearer {}".format(access_token)}
    params = {"q": search_string,
              "type": "track"}
    r = requests.get("https://api.spotify.com/v1/search", headers=headers, params=params)
    tracks = r.json()['tracks']['items']
    print(tracks)

